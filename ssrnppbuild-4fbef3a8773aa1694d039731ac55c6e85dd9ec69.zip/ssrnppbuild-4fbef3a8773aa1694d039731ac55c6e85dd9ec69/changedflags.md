Storyflags

322: Repair Gondo's Junk Check (repurposed: "Learn about Scrapper near Village Windmill")

900: Beat Ancient Cistern
901: Beat Fire Sanctuary
11 & 13: Imp2 Requirements reached (should be set at once)
902: Beat Required dungeon 1
903: Beat Required dungeon 2

904: Progressive Mitts1 (Digging Mitts)
905: Progressive Mitts2 (Mogma Mitts)

906: Progressive Sword1 (Practice Sword)
907: Progressive Sword2 (Goddess Sword)
908: Progressive Sword3 (Goddess Long Sword)
909: Progressive Sword4 (Goddess White Sword)
910: Progressive Sword5 (Master Sword)
911: Progressive Sword6 (True Master Sword)

912: Progressive Beetle1
913: Progressive Beetle2 (Hook Beetle)

914: Change Temple of Time layer, storyflag 9 is associated with Harp

915: Medium Wallet
916: Big Wallet
917: Giant Wallet
918: Tycoon Wallet

New Trial Completed Storyflags:
919: Faron
920: Eldin
921: Lanayru
922: Skyloft

923: Obtained Item from Fledge at start
924: Obtained Item from Cawlin
925: Obtained Item from Strich

926: Required Dungeon 3
927: Required Dungeon 4
928: Required Dungeon 5
929: Required Dungeon 6

931: Adventure Pouch
932: Pouch Expansion

933: Defeat Tentalus
934: Obtained Item from Levias

935: Exit out of the back of LMF for the first time
936: Obtained Item at the end of LMF

937: Bought Beedle's first 100R item
938: Bought Beedle's second 100R item
939: Bought Beedle's third 100R item
940: Bought Beedle's Bug Net item
941: Bought Beedle's Bug Medal item

942: Progressive Beetle 3 (Swift Beetle)

943: Progressive Beetle 4 (Tough Beetle)

944: Progressive Bow 1 (Bow)

945: Progressive Bow 2 (Iron Bow)

946: Progressive Bow 3 (Sacred Bow)

947: Progressive Slingshot 1 (Slingshot)

948: Progressive Slingshot 2 (Scattershot)

949: Progressive Bug Net 1 (Bug Net)

950: Progressive Bug Net 2 (Big Bug Net)

951: Raising Goddess Sword in Goddess Statue

952: ***Reserved for Raising True Master Sword in Bokoblin Base***

953: Group of Tadtones Counter

Sceneflags

Skyloft:
101: Collected item from Knight Academy Bell

Ancient Cistern:
85: After receiving Item from flame CS

Sandship:
87: After receiving Item from flame CS
