## What does this PR do?
The fundamental code changes and what they translate to functionally.

## How do you test this changes?
How to test/recreate the issue/verify the changes.

## Notes
Any notes, additional thoughts, concerns or comments.
