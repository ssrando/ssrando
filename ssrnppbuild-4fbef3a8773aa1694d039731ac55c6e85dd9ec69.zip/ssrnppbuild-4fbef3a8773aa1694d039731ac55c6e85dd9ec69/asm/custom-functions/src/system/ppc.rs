extern "C" {
    pub fn float_to_unsigned(_: f32) -> u32;
}
